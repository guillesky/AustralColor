package vista_Progress;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.border.TitledBorder;

public class Ventana extends JFrame implements IVista, ActionListener
{

    private static final long serialVersionUID = 1L;
    private Controlador controlador;
    private JPanel contentPane;
    private JSplitPane splitPaneArribaAbajo;
    private JSplitPane splitPaneDerechaIzquierda;
    private JPanel panelWest;
    private JButton btnAgregar;
    private JButton btnProcesar;
    private JPanel panel_1;
    private JPanel panel_2;

    private JScrollPane scrollPane;
    private JTextArea textArea;
    private JScrollPane scrollPane_1;
    private JTable table;
    private JPanel panel_Derecha;
    private TableModelAbstractMediaTak modelo;

    private MediaFileChooser mediaFileChooser;
    private JPanel panel;
    private JPanel panel_3;
    private JMenuBar menuBar;
    private JMenu mnArchivo;
    private JMenuItem mnAgregarArchivos;
    private JMenu mnOpciones;
    private JMenu mnNewMenu_2;
    private JMenuItem mnProcesar;
    private JRadioButtonMenuItem rdbtnmntmSaltar;
    private JRadioButtonMenuItem rdbtnmntmSobreescribir;
    private JRadioButtonMenuItem rdbtnmntmRenombrar;
    private ButtonGroup group = new ButtonGroup();
    private JSpinner spinner;
    private JPanel panel_4;

    public Ventana()
    {
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setBounds(100, 100, 911, 300);

	this.menuBar = new JMenuBar();
	setJMenuBar(this.menuBar);

	this.mnArchivo = new JMenu("Archivos");
	this.menuBar.add(this.mnArchivo);

	this.mnAgregarArchivos = new JMenuItem("Agregar Archivos");
	this.mnArchivo.add(this.mnAgregarArchivos);

	this.mnProcesar = new JMenuItem("Procesar");
	this.mnArchivo.addSeparator();
	this.mnArchivo.add(this.mnProcesar);

	this.mnOpciones = new JMenu("Opciones");
	this.menuBar.add(this.mnOpciones);

	this.rdbtnmntmSaltar = new JRadioButtonMenuItem("Saltar Archivos Repetidos");
	this.rdbtnmntmSaltar.setSelected(true);
	this.mnOpciones.add(this.rdbtnmntmSaltar);

	this.rdbtnmntmSobreescribir = new JRadioButtonMenuItem("Sobreescribir Archivos Repetidos");
	this.mnOpciones.add(this.rdbtnmntmSobreescribir);

	this.rdbtnmntmRenombrar = new JRadioButtonMenuItem("Renombrar Archivos Repetidos");
	this.mnOpciones.add(this.rdbtnmntmRenombrar);

	this.mnNewMenu_2 = new JMenu("New menu");
	this.menuBar.add(this.mnNewMenu_2);
	this.contentPane = new JPanel();
	this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	setContentPane(this.contentPane);
	this.contentPane.setLayout(new BorderLayout(0, 0));

	this.splitPaneArribaAbajo = new JSplitPane();
	this.splitPaneArribaAbajo.setOrientation(JSplitPane.VERTICAL_SPLIT);
	this.contentPane.add(this.splitPaneArribaAbajo);
	this.splitPaneDerechaIzquierda = new JSplitPane();

	this.splitPaneArribaAbajo.setLeftComponent(splitPaneDerechaIzquierda);

	this.scrollPane = new JScrollPane();
	this.splitPaneArribaAbajo.setRightComponent(this.scrollPane);

	this.splitPaneArribaAbajo.setResizeWeight(0.8);
	this.splitPaneDerechaIzquierda.setResizeWeight(0.8);

	this.scrollPane_1 = new JScrollPane();
	this.splitPaneDerechaIzquierda.setLeftComponent(this.scrollPane_1);
	this.modelo = new TableModelAbstractMediaTak();
	this.table = new JTableWithProgress(modelo, 1);
	this.scrollPane_1.setViewportView(this.table);

	panel_Derecha = new JPanel();
	splitPaneDerechaIzquierda.setRightComponent(panel_Derecha);
	this.textArea = new JTextArea();
	this.scrollPane.setViewportView(this.textArea);

	this.panelWest = new JPanel();
	this.contentPane.add(this.panelWest, BorderLayout.WEST);
	this.panelWest.setLayout(new GridLayout(0, 1, 0, 0));

	this.panel_1 = new JPanel();
	this.panelWest.add(this.panel_1);
	this.panel_1.setLayout(new GridLayout(0, 1, 0, 0));

	this.panel = new JPanel();
	this.panel_1.add(this.panel);

	this.btnAgregar = new JButton("Agregar Archivos");
	this.panel.add(this.btnAgregar);
	this.btnAgregar.addActionListener(this);
	this.btnAgregar.setActionCommand(IVista.ADD_FILES);

	this.panel_3 = new JPanel();
	this.panel_1.add(this.panel_3);

	this.btnProcesar = new JButton("Procesar");
	this.panel_3.add(this.btnProcesar);
	this.btnProcesar.setActionCommand(IVista.START_TASK);
	
	this.panel_4 = new JPanel();
	this.panelWest.add(this.panel_4);
	
	this.spinner = new JSpinner();
	this.panel_4.add(this.spinner);
	this.spinner.setToolTipText("");

	this.panel_2 = new JPanel();
	this.panel_2.setBorder(new TitledBorder(null, "Procesos Simultaneos", TitledBorder.LEADING, TitledBorder.TOP, null, null));
	this.panelWest.add(this.panel_2);

	File currentDir = new File(System.getProperty("user.dir"));
	this.mediaFileChooser = new MediaFileChooser(currentDir);
	this.group.add(rdbtnmntmSaltar);
	this.group.add(rdbtnmntmSobreescribir);
	this.group.add(rdbtnmntmRenombrar);

	this.setVisible(true);

    }

    @Override
    public void setControlador(Controlador controlador)
    {
	this.controlador = controlador;
	this.btnProcesar.addActionListener(controlador);

    }

    private void agregarArchivos()
    {
	if (this.mediaFileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
	{
	    this.controlador.addFiles(mediaFileChooser.getSelectedFiles());

	}
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {

	this.agregarArchivos();

    }

    @Override
    public void updateTaskVisualization()
    {
	SwingUtilities.invokeLater(new Runnable()
	{
	    @Override
	    public void run()
	    {
		modelo.fireTableDataChanged();
	    }
	});
    }

    @Override
    public void addTasks(ArrayList<AbstractMediaTask> abstractMediaTasks)
    {
	for (AbstractMediaTask m : abstractMediaTasks)
	    this.modelo.addAbstractMediaTask(m);

    }

    @Override
    public void removeTasks(AbstractMediaTask abstractMediaTask)
    {
	this.modelo.removeAbstractMediaTask(abstractMediaTask);

    }
public static void main(String[] args)
{
    Ventana v=new Ventana();
}
}
